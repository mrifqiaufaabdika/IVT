<?php
mysql_connect("localhost","id1660195_a","123456");
mysql_select_db("id1660195_cbms_ivt");
?>
