<?php
header(sprintf('location:view/login.php'));
 ?>
